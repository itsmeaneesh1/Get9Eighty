import { Component, OnInit ,Input} from '@angular/core';
import { Customer } from '../customer';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  cust:Customer=new Customer();

  constructor(private myservice:MyserviceService) { }
  
  saveCustomer(custData:any)
  {
    this.cust=custData.value;
    this.myservice.addCustomer(this.cust);  
  }

  

  fname:any;
  addFruit()
  {
      this.myservice.addFruit(this.fname);
  }

  @Input() printValue='';

  
  

  
  ngOnInit(): void 
  {
  }

}
