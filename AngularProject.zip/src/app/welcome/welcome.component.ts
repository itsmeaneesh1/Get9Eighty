import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  loginform=new FormGroup(
    {
        loginid:new FormControl('',[Validators.required]),
        passwd:new FormControl('',[Validators.required]) 
    }
  )
  logindata:any;
  loginError:any;
  validateLogin()
  {
      this.logindata=this.loginform.value;
      if(this.logindata.loginid=="sa" && this.logindata.passwd=="pass")
      {
         this.myrouter.navigate(['home',this.logindata.loginid]);
      }
      else
      {
        this.loginError="Invalid User";
      }
    }
  constructor(private myrouter:Router) { }

  ngOnInit(): void {
  }

  

}
