import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FirstApp';

  constructor(private myrouter:Router){}

  goHome()
  {
      this.myrouter.navigate(['home']);
  }







  someValue="";

  saveData(ss:string)
{
  this.someValue=ss;
}

  itemToSend:string="Sample Item";

  itemsArray=['Item 1','Item 2'];

  addItem(newItem:string)
  {
    this.itemsArray.push(newItem);
  }


}
