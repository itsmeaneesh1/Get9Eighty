export class Customer
{
    custid:string|undefined;
    custname:string|undefined;
    custage:number|undefined;
    custemail:string|undefined;

}
