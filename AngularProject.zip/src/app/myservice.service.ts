import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  
  httpUrl:string="https://jsonplaceholder.typicode.com/posts/1/comments";

  constructor(private myhttp:HttpClient) { }
 
  fetchAllServerData()
  {
      return this.myhttp.get(this.httpUrl);
  }



  custArray=new Array<Customer>();

  addCustomer(customer:Customer)
  {
    this.custArray.push(customer);
  }
  getCustomers()
  {
      return this.custArray;
  }








  fruitsArray=new Array<string>();

  

  addFruit(fruitname:string)
  {
     this.fruitsArray.push(fruitname);
  }
  getfruits()
  {
    return this.fruitsArray;
  }



}
