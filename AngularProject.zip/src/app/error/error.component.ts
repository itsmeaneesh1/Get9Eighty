import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-error',
  template: '<div>  </div>',
  styles: ['.myclass{ color:red }']
})
export class ErrorComponent implements OnInit {

  constructor(private mys:MyserviceService) { }
  //fruits:any;
  ngOnInit(): void
   {
     // this.fruits=this.mys.getfruits();
  }

}
