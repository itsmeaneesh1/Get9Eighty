import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditcustomerComponent } from './editcustomer/editcustomer.component';
import { ErrorComponent } from './error/error.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { ShowcustomerComponent } from './showcustomer/showcustomer.component';
import { SignupComponent } from './signup/signup.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
    { path:'',component:WelcomeComponent},//DEFAULT ROUTE
    { path:'home' ,component:HomeComponent},
    { path:'home/:loginid' ,component:HomeComponent},
    { path:'login',component:LoginComponent},
    { path:'register',component:SignupComponent},
    { path:'showprof',component:ProfileComponent},
    { path:'showcust',component:ShowcustomerComponent},
    { path:'register/editcustomer/:custid',component:EditcustomerComponent},
    { path:'**',component:ErrorComponent} //WILDCARD ROUTE
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
