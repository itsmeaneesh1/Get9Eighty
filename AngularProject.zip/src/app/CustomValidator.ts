import { AbstractControl, ValidationErrors } from '@angular/forms';

export class CustomValidator 
{

        static strLength(control:AbstractControl):ValidationErrors|null{
            const str=control.value as string;
            if(str.length!=10 || str.match("^[a-zA-Z]+$"))
            {
                return {'customValidator':{ "valid": false }}
            }
            return null;
        }
       
}