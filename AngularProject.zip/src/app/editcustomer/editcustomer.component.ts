import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {

  constructor(private activeRoute : ActivatedRoute) { }
  customerid:any;
  ngOnInit(): void {
      this.activeRoute.paramMap.subscribe(
          params=>{
              console.log(params);
              this.customerid=params.get('custid');
          }
      )

  }
}
