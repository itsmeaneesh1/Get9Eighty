
import { Component, Output, OnInit, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  template: `
  <div>
    <form [formGroup]="loginForm" (ngSubmit)="loginUser()">
      <input type="text" id="username-input" formControlName="username" >
      <input type="password" id="password-input" formControlName="password">
      <input type="submit" id="login-button" value="Login" [disabled]="!loginForm.valid">
    </form>
  </div>
  `
})
export class LoginComponent implements OnInit {

  @Output() login: EventEmitter<any> = new EventEmitter();
  loginForm=new FormGroup({
    username:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)
  })
  loginUser()
  {
    this.login.emit(this.loginForm.value);
  }

  // str1:string="ABC";
  // arr1=["Apple","Grape","Pineapple","Banana","Guava"]
  // fruits={
  //     fname:'Apple', 
  //     fprice:230 
  //  }
  //  fruitsList=[
  //   { fname:'Appple' ,fprice:230},
  //   { fname:'Grape' ,fprice:130},
  //   { fname:'Guava' ,fprice:120},
  //   { fname:'Banana' ,fprice:60}
  //  ]
  constructor() {
   
   }
  ngOnInit(): void 
  {

  }

}
