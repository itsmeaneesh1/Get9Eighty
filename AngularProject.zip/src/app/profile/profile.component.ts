import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import  { ageValidator } from '../Age.validator';
import { CustomValidator } from '../CustomValidator';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  @Output() typedValue=new EventEmitter<string>();
 
  sendtoParent(str:string) {
      this.typedValue.emit(str);
   }

  //weekdays=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  //paymentType:string="";
  //banks=['ICICI','SBI','SC','HDFC'];

  custForm=new FormGroup(
    {
      custid:new FormControl('',[Validators.required,Validators.minLength(4)]),
    //  custname:new FormControl('',[Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
    custname:new FormControl('',CustomValidator.strLength), 
    custage:new FormControl('',[Validators.required ,ageValidator]),
      custemail:new FormControl('',[Validators.required,Validators.email])
    }
  )
  saveCustomer()
  {
    console.log(this.custForm.value);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
