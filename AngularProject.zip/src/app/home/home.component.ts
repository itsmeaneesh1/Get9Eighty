import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 // <button (click)="swapImage()">SWAP</button><br>
//  <img [src]="imageSrc" height="270" width="200">

  imageSrc:string="/assets/kohli.png";
  clicked:boolean=false;
swapImage()
{
    if(this.clicked)
    {
      this.imageSrc="/assets/kohli.png";
        this.clicked=false;       
    }  
    else
    {
      this.imageSrc="/assets/sachin.jpg";
      this.clicked=true;
    } 
}





// txt:string="Enter Something";

  // color=["red","green","yellow","orange","pink"];
  // colorSelected:any; 
  // disableButton:boolean=false;
 
  loginid:string="";
  passwd:string="";
  logMsg:string="";
  spanclass:string="";
  validateLogin()
  {
      if(this.loginid=="sa"&&this.passwd=="pass123")
          { this.logMsg="Valid User";
            this.spanclass="validuser";
          } 
      else
          {  this.logMsg="Invalid User";
            this.spanclass="invaliduser";
        }
  }
  //<span [class]="spanclass">
  //{{logMsg}}    
//</span>

   constructor(private actRoute:ActivatedRoute) { }
   logid:any;
  ngOnInit(): void {
      this.actRoute.paramMap.subscribe(
        (params)=>{
                this.logid=params.get('loginid');
        }
      )
  }
  

}
