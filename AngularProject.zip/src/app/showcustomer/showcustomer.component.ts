import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-showcustomer',
  templateUrl: './showcustomer.component.html',
  styleUrls: ['./showcustomer.component.css']
})
export class ShowcustomerComponent implements OnInit {
  custArray:any;
  
  constructor(private myservice:MyserviceService) { }
  dataFromRemote:any;
  ngOnInit(): void 
  {
    this.myservice.fetchAllServerData().subscribe(
      (data)=>{
            console.log(data);
            this.dataFromRemote=data;
            console.log(this.dataFromRemote);
      },
      (error)=>
      {
          console.log(error);
      }
      
    )
      //this.custArray=this.myservice.getCustomers();
     // console.log(this.custArray);
  }

}
